using System;
using Expedia;
using NUnit.Framework;

namespace ExpediaTest
{
	[TestFixture()]
	public class FlightTest
	{
        private Flight flightOne;

        [SetUp()]
        public void init()
        {
            flightOne = new Flight(new DateTime(2012, 3, 12), new DateTime(2012, 5, 26), 1999);
        }

        [Test()]
        public void TestThatFlightInitializes()
        {
            var target = new Flight(new DateTime(2012, 4, 10), new DateTime(2012, 4, 15), 2000);
            Assert.IsNotNull(target);
        }

        [Test()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestThatFlightThrowsOnBadDate()
        {
            new Flight(new DateTime(2012, 4, 15), new DateTime(2012, 4, 10), 2000);
        }

        [Test()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestThatFlightThrowsOnNegativeDistance()
        {
            new Flight(new DateTime(2012, 4, 10), new DateTime(2012, 4, 15), -2000);
        }

        [Test()]
        public void TestThatIfObjectIsFlightCallThisEqualsTrue()
        {
            var flightTwo = new Flight(new DateTime(2012, 3, 12), new DateTime(2012, 5, 26), 1999);
            Assert.True(flightOne.Equals(flightTwo));
        }

        [Test()]
        public void TestThatIfObjectIsFlightCallThisEqualsFalse()
        {
            var flightTwo = new Flight(new DateTime(2012, 3, 11), new DateTime(2012, 5, 26), 1999);
            Assert.False(flightOne.Equals(flightTwo));
        }

        [Test()]
        public void TestThatMilesGetterWorks()
        {
            Assert.AreEqual(flightOne.Miles, 1999);
        }
	}
}
